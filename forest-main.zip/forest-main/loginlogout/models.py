from django.db import models
from uuid import uuid4


class User(models.Model):
    username = models.CharField(max_length=255, null=False)
    email = models.EmailField(max_length=255, null=False)
    password = models.CharField(max_length=50)
    ifLogged = models.BooleanField(default=False)
    token = models.CharField(max_length=500, null=True, default="")

    def __str__(self):
        return "{} -{}".format(self.username, self.email)


class Token(models.Model):
    token = models.CharField(max_length=255, null=False, default=uuid4())
    is_registered = models.BooleanField(default=False)
    email = models.EmailField(max_length=255, null=False)

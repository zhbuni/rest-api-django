from django.apps import AppConfig


class LoginlogoutConfig(AppConfig):
    name = 'loginlogout'
